package com.calc.qa.operations;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.calc.qa.base.BaseCalculator;

public class Division extends BaseCalculator {

	@FindBy(name="Divide")
	WebElement divide;

	@FindBy(id="150")
	WebElement result;

	@FindBy(name="Equals")
	WebElement equals;

	public Division(){
		PageFactory.initElements(driver, this);
	}

	public String divideZero(String number1, String number2) throws Exception{

		number(number1);

		divide.click();

		number(number2);

		equals.click();
		Thread.sleep(2000);
		String message = result.getAttribute("Name");
		return message;

	}
	public double divide(String number1, String number2) throws Exception{
		number(number1);

		divide.click();

		number(number2);

		equals.click();
		Thread.sleep(2000);
		String output = result.getAttribute("Name");
		return Double.parseDouble(output);
	}
}
