package com.calc.qa.operations;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.calc.qa.base.BaseCalculator;

public class Modulo extends BaseCalculator{

	@FindBy(name="Modulo")
	WebElement mod;

	@FindBy(id="150")
	WebElement result;

	@FindBy(name="Equals")
	WebElement equals;

	public Modulo(){
		PageFactory.initElements(driver, this);
	}

	public int mod(String number1,String number2) throws Exception{

		number(number1);

		mod.click();

		number(number2);

		equals.click();
		Thread.sleep(2000);
		String output = result.getAttribute("Name");
		return Integer.parseInt(output);
	}

}
