package com.calc.qa.base;

import java.net.URL;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.winium.DesktopOptions;
import org.openqa.selenium.winium.WiniumDriver;

public class BaseCalculator {

	public static DesktopOptions option;
	public static WiniumDriver driver;
	public static Properties prop;

	public BaseCalculator(){

	}

	public void initialize(){
		try {
			option = new DesktopOptions();
			option.setApplicationPath("C:\\Windows\\System32\\calc.exe");
			driver = new WiniumDriver(new URL("http://localhost:9999"), option);
		}
		catch (Exception e) {
			e.printStackTrace();

		}
	}

	public void scientificCalculator(){
		try{
			driver.findElement(By.name("View")).click();
			Thread.sleep(3000);
			driver.findElement(By.name("Scientific")).click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void standardCalculator(){
		try{
			driver.findElement(By.name("View")).click();
			Thread.sleep(3000);
			driver.findElement(By.name("Standard")).click();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void closeApp(){
		driver.findElement(By.name("Close")).click();
	}

	public void number(String number){

		for(int i=0;i<number.length();i++){
			switch(number.charAt(i)){
			case '0':
				driver.findElementById("130").click();
				break;

			case '1':
				driver.findElementById("131").click();
				break;

			case '2':
				driver.findElementById("132").click();
				break;

			case '3':
				driver.findElementById("133").click();
				break;

			case '4':
				driver.findElementById("134").click();
				break;

			case '5':
				driver.findElementById("135").click();
				break;

			case '6':
				driver.findElementById("136").click();
				break;

			case '7':
				driver.findElementById("137").click();
				break;

			case '8':
				driver.findElementById("138").click();
				break;

			case '9':
				driver.findElementById("139").click();
				break;

			case '.':
				driver.findElementByName("Decimal separator").click();
				break;

			default:
				break;

			}
		}
	}

}
