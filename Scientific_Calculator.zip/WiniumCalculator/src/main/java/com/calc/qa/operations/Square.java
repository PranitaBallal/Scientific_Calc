package com.calc.qa.operations;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.calc.qa.base.BaseCalculator;

public class Square extends BaseCalculator{

	@FindBy(name="Square")
	WebElement sqr;

	@FindBy(id="150")
	WebElement result;

	@FindBy(name="Equals")
	WebElement equals;

	public Square(){
		PageFactory.initElements(driver, this);
	}

	public double square(String number,int square) throws Exception{
		number(number);

		for(int i=0;i<square;i++){

			sqr.click();
		}	

		equals.click();

		String output = result.getAttribute("Name");
		Thread.sleep(2000);
		return Double.parseDouble(output);	

	}
}
