package com.calc.qa.operations;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.calc.qa.base.BaseCalculator;

public class Addition extends BaseCalculator{
	@FindBy(name="Add")
	WebElement add;

	@FindBy(id="150")
	WebElement result;

	@FindBy(name="Equals")
	WebElement equals;

	public Addition(){
		PageFactory.initElements(driver, this);
	}
	public double addition(String number1, String number2) throws Exception
	{
		number(number1);
		add.click();
		number(number2);
		equals.click();
		String output = result.getAttribute("Name");
		Thread.sleep(2000);
		return Double.parseDouble(output);

	}
}
