package com.calc.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.calc.qa.base.BaseCalculator;
import com.calc.qa.operations.Modulo;

public class ModuloTest extends BaseCalculator{
	public static String number1 = null;
	public static String number2 = null;

	@BeforeClass
	public void launchApp(){
		initialize();
	}

	@BeforeMethod
	public void scientificCalc(){

		scientificCalculator();

	}

	@Test
	@Parameters({"number1_mod","number2_mod"})
	public void moduloTest(String number1,String number2) throws Exception{
		Modulo m = new Modulo();
		int mod  = m.mod(number1, number2);
		int modulo = Integer.parseInt(number1)%Integer.parseInt(number2);
		Assert.assertEquals(mod, modulo, "Modulo functionality is not working properly.");
	}


	@AfterMethod
	public void standardCalc(){
		standardCalculator();
	}

	@AfterClass
	public void close(){
		closeApp();
	}

}
