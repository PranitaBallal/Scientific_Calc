package com.calc.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.calc.qa.base.BaseCalculator;
import com.calc.qa.operations.Square;

public class SquareTest extends BaseCalculator{
	public static String number1 = null;
	public static String number2 = null;
	public static int square = 0;

	@BeforeClass
	public void launchApp(){
		initialize();
	}

	@BeforeMethod
	public void scientificCalc(){

		scientificCalculator();

	}

	@Test
	@Parameters({"exponent","power"})
	public void sqrTest(String number1,String number2) throws Exception{
		double sqr = Integer.parseInt(number1);
		int square = Integer.parseInt(number2);
		Square s = new Square();
		double ss  = s.square(number1, square);
		for(int i=0;i<square;i++){
			sqr = sqr*sqr;
		}
		Assert.assertEquals(ss, sqr, "Square functionality is not working properly.");
	}


	@AfterMethod
	public void standardCalc(){
		standardCalculator();
	}

	@AfterClass
	public void close(){
		closeApp();
	}

}

