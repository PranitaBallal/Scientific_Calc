package com.calc.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.calc.qa.base.BaseCalculator;
import com.calc.qa.operations.Division;

public class DivisionTest extends BaseCalculator {

	@BeforeClass
	public void launchApp(){
		initialize();
	}

	@BeforeMethod
	public void scientificCalc(){

		scientificCalculator();

	}

	@Test
	@Parameters({"number1_div","number2_div"})
	public void divisionTest(String number1,String number2) throws Exception{
		Division div = new Division();
		if(number2.equals("0")){
			String division = div.divideZero(number1, number2);
			Assert.assertEquals(division, "Cannot divide by zero", "Division functionality is not working properly for divide by zero case.");
		}
		else{
			double division1 = div.divide(number1, number2);
			double divide = Double.parseDouble(number1)/Double.parseDouble(number2);
			Assert.assertEquals(division1, divide, "Division functionality is not working properly.");
		}
	}


	@AfterMethod
	public void standardCalc(){
		standardCalculator();
	}

	@AfterClass
	public void close(){
		closeApp();
	}

}
