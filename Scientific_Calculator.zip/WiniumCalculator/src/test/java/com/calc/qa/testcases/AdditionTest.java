package com.calc.qa.testcases;


import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.calc.qa.base.BaseCalculator;
import com.calc.qa.operations.Addition;

public class AdditionTest extends BaseCalculator {

	public static String number1 = null;
	public static String number2 = null;

	@BeforeClass
	public void launchApp(){
		initialize();
	}

	@BeforeMethod
	public void scientificCalc(){

		scientificCalculator();

	}

	@Test(priority = 1)
	@Parameters({"number1_add","number2_add"})
	public void additionTest(String number1,String number2) throws Exception{
		Addition add = new Addition();
		double addition = add.addition(number1, number2);
		double sum = Double.parseDouble(number1)+Double.parseDouble(number2);
		Assert.assertEquals(addition, sum, "Addition functionality is not working properly.");
	}


	@AfterMethod
	public void standardCalc(){
		standardCalculator();
	}

	@AfterClass
	public void close(){
		closeApp();
	}

}
